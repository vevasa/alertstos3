exports.work = require('./lib/example');
