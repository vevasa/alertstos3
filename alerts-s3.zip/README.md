# ts-webhook-example
Example Webhook running on AWS Lambda


#How To

Copy the config over and fill in the values.
```
cp config.json.example config.json
```

Open the *config.json* with your favorite editor and go over to the Threat Stack daschboard and retreive your API Key from the `Application Keys` page in the settings. Fill in your organization and finally fill in your s3 bucket you'll be using.

Zip it up and deploy the code as you would for any other lambda function using the command below as a reference:

```
aws lambda create-function --function-name some-webhook --runtime nodejs --role "some_role" --handler webhook.work --zip-file fileb://./webhook.zip
```

After that point your API gateway at the lambda function and you should be all set. 

#S3 Layout

This function simply takes the current date and puts it into the following format: `YYYY-MM-DD` and appends this to your s3 bucket in `config.json`. Then the alerts themselves are stored in s3 with the following format `<alert_id>.json`.

